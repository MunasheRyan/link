def sort_stack(stack):
    helper = []

    while stack:
        current = stack.pop()

        while helper and helper[-1] > current:
            stack.append(helper.pop())

        helper.append(current)

    # Final transfer back to original stack (sorted, smallest on top)
    while helper:
        stack.append(helper.pop())

    return stack


def load_numbers(filepath):
    numbers = []
    try:
        with open(filepath, 'r') as file:
            for line in file:
                value = line.strip()
                if value:
                    numbers.append(int(value))
    except FileNotFoundError:
        print(f"File not found: {filepath}")
    return numbers


def run_sorting():
    path = "List_Unique_10000.txt"
    stack_data = load_numbers(path)

    import time
    start = time.time()
    sort_stack(stack_data)
    end = time.time()

    # Verify sorting
    is_sorted = all(stack_data[i] <= stack_data[i + 1] for i in range(len(stack_data) - 1))
    duration = round(end - start, 3)

    print(f"Sorted? {is_sorted}")
    print(f"Execution Time: {duration} seconds")
    print(f"Stack Size: {len(stack_data)}")

    # Optional: print result (commented out to avoid flooding output)
    # for val in stack_data:
    #     print(val)


if __name__ == "__main__":
    run_sorting()
