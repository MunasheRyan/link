class Node:
    """Node class for singly linked list."""
    def __init__(self, value):
        self.value = value
        self.next = None

class SinglyLinkedList:
    """Custom singly linked list class."""
    def __init__(self):
        self.head = None
        self._size = 0

    def push(self, value):
        """Push value to the front of the list."""
        new_node = Node(value)
        new_node.next = self.head
        self.head = new_node
        self._size += 1

    def pop(self):
        """Remove and return the value from the front of the list."""
        if self.is_empty():
            raise IndexError("Pop from empty list")
        value = self.head.value
        self.head = self.head.next
        self._size -= 1
        return value

    def top(self):
        """Return value at the front without removing it."""
        if self.is_empty():
            raise IndexError("Top from empty list")
        return self.head.value

    def is_empty(self):
        """Check if the list is empty."""
        return self.head is None

    def __len__(self):
        """Return number of elements in the list."""
        return self._size

    def find(self, x):
        """Return True if x is in the list, False otherwise."""
        current = self.head
        while current:
            if current.value == x:
                return True
            current = current.next
        return False

    def remove(self, x):
        """Remove first occurrence of x from the list. Return True if successful."""
        current = self.head
        prev = None
        while current:
            if current.value == x:
                if prev:
                    prev.next = current.next
                else:
                    self.head = current.next
                self._size -= 1
                return True
            prev = current
            current = current.next
        return False

def load_integers(filename):
    """Load integers from a file, one per line."""
    with open(filename, 'r') as file:
        return [int(line.strip()) for line in file.readlines() if line.strip().isdigit()]

def main():
    linked_list = SinglyLinkedList()
    numbers = load_integers("integers.txt")
    
    for number in numbers:
        linked_list.push(number)

    print(f"List size after loading: {len(linked_list)}")

    print("Top of the list:", linked_list.top())
    print("Find 73835667:", linked_list.find(73835667))
    print("Remove 73835667:", linked_list.remove(73835667))
    print("Find 73835667 again:", linked_list.find_
