import time
from collections import defaultdict

def load_resistor_data(path):
    connections = []
    with open(path, 'r') as f:
        for entry in f:
            if entry.strip():
                node1, node2, resistance = entry.strip().split(',')
                connections.append((int(node1), int(node2), float(resistance)))
    return connections

def create_network_map(connections):
    graph = defaultdict(list)
    for n1, n2, res in connections:
        graph[n1].append((n2, res))
        graph[n2].append((n1, res))
    return graph

def identify_terminals(connections):
    frequency = defaultdict(int)
    for x, y, _ in connections:
        frequency[x] += 1
        frequency[y] += 1
    # Terminal nodes are assumed to be those that appear only once
    terminal_nodes = [node for node, freq in frequency.items() if freq == 1]
    if len(terminal_nodes) >= 2:
        return terminal_nodes[0], terminal_nodes[1]
    # Fallback: choose two extremal nodes
    nodes = list(frequency.keys())
    return min(nodes), max(nodes)

def discover_paths(graph, source, target, max_depth=20, max_paths=1000):
    stack = [(source, [source], {source}, 0.0)]
    valid_paths = []
    shortest_length = float('inf')

    while stack and len(valid_paths) < max_paths:
        current, path, seen, path_sum = stack.pop()
        if len(path) > max_depth or path_sum > shortest_length * 2:
            continue
        if current == target:
            valid_paths.append((path, path_sum))
            shortest_length = min(shortest_length, path_sum)
            continue
        for neighbor, res in graph[current]:
            if neighbor not in seen:
                stack.append((
                    neighbor,
                    path + [neighbor],
                    seen | {neighbor},
                    path_sum + res
                ))
    return valid_paths

def calculate_equivalent_resistance(graph, start_node, end_node):
    paths = discover_paths(graph, start_node, end_node)
    if not paths:
        return float('inf')

    reciprocal_sum = 0.0
    for _, resistance in paths:
        if resistance > 0:
            reciprocal_sum += 1.0 / resistance

    # NOTE: This assumes all discovered paths are valid and purely in parallel,
    # which is not strictly correct for complex networks with shared resistors.
    return 1.0 / reciprocal_sum if reciprocal_sum != 0 else float('inf')

if __name__ == "__main__":
    input_file = "largeResNetwork.txt"  # Change to smallResNetwork.txt for testing
    start_time = time.time()

    resistor_links = load_resistor_data(input_file)
    network_graph = create_network_map(resistor_links)
    terminal_a, terminal_b = identify_terminals(resistor_links)
    result_resistance = calculate_equivalent_resistance(network_graph, terminal_a, terminal_b)

    end_time = time.time()

    print(f"Terminals: {terminal_a} → {terminal_b}")
    print(f"Approximate equivalent resistance: {round(result_resistance, 3)} kΩ")
    print(f"Execution time: {round(end_time - start_time, 4)} seconds")
